<template>
    <div class="min-h-screen" 
    style="
    background-image: url(images/login-background.jpg);
    height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    ">
        <slot />
    </div>
</template>

<script>
export default {
    setup() {
        
    },
}
</script>